# Sports app

<Put repo description here>

### Install Dependencies

Run the following command to install all dependencies.

```
npm install

npm start
```

### Setup Environment Variables

You will need to configure environment variables before starting the service.  Environment variables are used to configure the service.  Check .env-sample for a list of available options.

Start by creating a .env file then adding the variables you want to set.

PORT=3001

